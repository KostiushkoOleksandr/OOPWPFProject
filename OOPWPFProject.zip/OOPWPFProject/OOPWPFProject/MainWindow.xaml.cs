using System.Text;
using System.Windows;
using System.Windows.Controls;

namespace OOPWPFProject
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void AddRecord_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Інформація про авто:");
            sb.AppendLine($"Марка: {(BrandComboBox.SelectedItem as ComboBoxItem)?.Content}");
            sb.AppendLine($"Модель: {(ModelComboBox.SelectedItem as ComboBoxItem)?.Content}");
            sb.AppendLine($"Рік випуску: {YearTextBox.Text}");

            if (EngineTypeComboBox.SelectedItem is ComboBoxItem engine)
                sb.AppendLine($"Тип двигуна: {engine.Content}");

            if (!string.IsNullOrWhiteSpace(MileageTextBox.Text))
                sb.AppendLine($"Пробіг: {MileageTextBox.Text} км");

            ResultTextBlock.Text = sb.ToString();
        }

        private void ClearForm_Click(object sender, RoutedEventArgs e)
        {
            BrandComboBox.SelectedIndex = -1;
            ModelComboBox.SelectedIndex = -1;
            YearTextBox.Clear();
            EngineTypeComboBox.SelectedIndex = -1;
            MileageTextBox.Clear();
            ResultTextBlock.Text = "";
        }
    }
}

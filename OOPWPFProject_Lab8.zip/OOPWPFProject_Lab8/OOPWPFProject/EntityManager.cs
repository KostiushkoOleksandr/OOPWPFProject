﻿using System;
using System.Collections.ObjectModel;
using System.Text;

namespace OOPWPFProject
{
    public class EntityManager
    {
        public ObservableCollection<Car> Items { get; private set; }

        public EntityManager()
        {
            Items = new ObservableCollection<Car>();
        }

        public Car this[int index]
        {
            get
            {
                if (index < 0 || index >= Items.Count)
                {
                    throw new IndexOutOfRangeException("Індекс знаходиться поза межами колекції.");
                }
                return Items[index];
            }
            set
            {
                if (index < 0 || index >= Items.Count)
                {
                    throw new IndexOutOfRangeException("Індекс знаходиться поза межами колекції.");
                }
                Items[index] = value;
            }
        }

        public void Add(Car item)
        {
            Items.Add(item);
        }

        public void Remove(Car item)
        {
            Items.Remove(item);
        }

        public string DisplayAll()
        {
            if (Items.Count == 0)
            {
                return "Список порожній.";
            }

            StringBuilder sb = new StringBuilder();
            foreach (var car in Items)
            {
                sb.AppendLine(car.ToString());
            }
            return sb.ToString();
        }
    }
}
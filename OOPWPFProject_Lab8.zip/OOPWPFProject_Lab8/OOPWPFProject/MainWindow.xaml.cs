using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace OOPWPFProject
{
    public partial class MainWindow : Window
    {
        public EntityManager CarManager { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            CarManager = new EntityManager();
            this.DataContext = CarManager;
        }

        private void AddRecord_Click(object sender, RoutedEventArgs e)
        {
            if (BrandComboBox.SelectedItem == null || ModelComboBox.SelectedItem == null || string.IsNullOrWhiteSpace(YearTextBox.Text))
            {
                MessageBox.Show("Марка, модель та рік є обов'язковими полями.", "Помилка валідації", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            AddCarToList(
                (BrandComboBox.SelectedItem as ComboBoxItem).Content.ToString(),
                (ModelComboBox.SelectedItem as ComboBoxItem).Content.ToString(),
                YearTextBox.Text,
                (EngineTypeComboBox.SelectedItem as ComboBoxItem)?.Content.ToString(),
                MileageTextBox.Text
            );
        }

        private void AddCarToList(string brand, string model, string yearStr, string engineType, string mileageStr)
        {
            try
            {
                if (!int.TryParse(yearStr, out int year))
                {
                    MessageBox.Show($"Будь ласка, введіть коректний рік випуску.", "Помилка валідації", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                var car = new Car(brand, model, year);
                car.EngineType = engineType;

                if (!string.IsNullOrWhiteSpace(mileageStr) && int.TryParse(mileageStr, out int mileage) && mileage >= 0)
                {
                    car.Mileage = mileage;
                }

                CarManager.Add(car);
                ClearForm();
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show(ex.Message, "Помилка валідації", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void DeleteRecord_Click(object sender, RoutedEventArgs e)
        {
            if (CarsDataGrid.SelectedItem is Car selectedCar)
            {
                CarManager.Remove(selectedCar);
            }
            else
            {
                MessageBox.Show("Будь ласка, виберіть запис для видалення.", "Інформація", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void SortButton_Click(object sender, RoutedEventArgs e)
        {
            if (SortFieldComboBox.SelectedItem == null)
            {
                MessageBox.Show("Будь ласка, оберіть поле для сортування.", "Інформація", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            string field = (SortFieldComboBox.SelectedItem as ComboBoxItem).Content.ToString();
            bool isDescending = SortDescendingCheckBox.IsChecked == true;

            var sortedCars = new List<Car>();
            switch (field)
            {
                case "Маркою":
                    sortedCars = isDescending ? CarManager.Items.OrderByDescending(c => c.Brand).ToList() : CarManager.Items.OrderBy(c => c.Brand).ToList();
                    break;
                case "Моделлю":
                    sortedCars = isDescending ? CarManager.Items.OrderByDescending(c => c.Model).ToList() : CarManager.Items.OrderBy(c => c.Model).ToList();
                    break;
                case "Роком":
                    sortedCars = isDescending ? CarManager.Items.OrderByDescending(c => c.Year).ToList() : CarManager.Items.OrderBy(c => c.Year).ToList();
                    break;
                case "Пробігом":
                    sortedCars = isDescending ? CarManager.Items.OrderByDescending(c => c.Mileage).ToList() : CarManager.Items.OrderBy(c => c.Mileage).ToList();
                    break;
            }

            CarManager.Items.Clear();
            foreach (var car in sortedCars)
            {
                CarManager.Add(car);
            }
        }

        private void GetByIndex_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!int.TryParse(IndexTextBox.Text, out int index))
                {
                    MessageBox.Show("Будь ласка, введіть коректний числовий індекс.", "Помилка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                Car car = CarManager[index];

                MessageBox.Show(car.ToString(), $"Інформація про об'єкт з індексом {index}", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (IndexOutOfRangeException ex)
            {

                MessageBox.Show(ex.Message, "Помилка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ClearForm_Click(object sender, RoutedEventArgs e) => ClearForm();

        private void ClearForm()
        {
            BrandComboBox.SelectedIndex = -1;
            ModelComboBox.SelectedIndex = -1;
            YearTextBox.Clear();
            EngineTypeComboBox.SelectedIndex = -1;
            MileageTextBox.Clear();
            IndexTextBox.Clear();
        }
    }
}
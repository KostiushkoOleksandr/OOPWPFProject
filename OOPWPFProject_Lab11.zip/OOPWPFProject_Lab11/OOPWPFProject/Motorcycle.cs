﻿using System;
using System.Windows; 

namespace OOPWPFProject
{
    
    public sealed class Motorcycle : Vehicle, IMaintainable
    {
        public bool HasSidecar { get; set; }
        public int MaxSpeed { get; set; }

      
        public DateTime LastMaintenanceDate { get; set; }
        public decimal MaintenanceCost { get; set; }

        public Motorcycle(string brand, string model, int year, bool hasSidecar, int maxSpeed)
            : base(brand, model, year)
        {
            HasSidecar = hasSidecar;
            MaxSpeed = maxSpeed;
            
            LastMaintenanceDate = DateTime.MinValue;
            MaintenanceCost = 0;
        }

        public override string GetDetails()
        {
            string baseDetails = base.GetDetails();
            return $"{baseDetails}\nНаявність коляски: {(HasSidecar ? "Так" : "Ні")}\nМакс. швидкість (км/год): {MaxSpeed}\n" +
                   $"Останнє обслуговування: {(LastMaintenanceDate == DateTime.MinValue ? "Не встановлено" : LastMaintenanceDate.ToShortDateString())}\nВартість обслуговування: {MaintenanceCost:C}";
        }

       
        public void ScheduleMaintenance()
        {
            MessageBox.Show($"Планується обслуговування для мотоцикла {Brand} {Model}. Перевірте рівень мастила та гальма.", "Планування обслуговування", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        public bool NeedsService()
        {
            
            return (DateTime.Now - LastMaintenanceDate).TotalDays > 180 && LastMaintenanceDate != DateTime.MinValue;
        }
    }
}
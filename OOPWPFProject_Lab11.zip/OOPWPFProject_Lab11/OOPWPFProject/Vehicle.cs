﻿using System;

namespace OOPWPFProject
{
    public abstract class Vehicle : AbstractVehicle
    {
        protected Vehicle(string brand, string model, int year)
            : base(brand, model, year)
        {
        }

        public override string GetDetails()
        {
            return $"Тип: {this.GetType().Name}\nМарка: {Brand}\nМодель: {Model}\nРік: {Year}";
        }

        public override string ToString()
        {
            return $"{Brand} {Model} ({Year})";
        }

        // Перевантаження оператора + для комбінування назв моделей
        public static Vehicle operator +(Vehicle v1, Vehicle v2)
        {
            if (v1 == null || v2 == null)
            {
                throw new ArgumentNullException("Обидва об'єкти транспортних засобів повинні бути ініціалізовані для операції '+'.");
            }

            // Створюємо новий автомобіль або мотоцикл з комбінованою моделлю.
            // Щоб уникнути помилок, припускаємо, що тип нового транспортного засобу буде таким же, як і у першого операнда.
            // В реальному проекті тут може бути складніша логіка, наприклад, повернення нового абстрактного типу або визначення найдоцільнішого типу.
            string combinedModel = $"{v1.Model}-{v2.Model}";
            string newBrand = v1.Brand; // Можна змінити логіку, наприклад, "Комбінована"
            int newYear = Math.Max(v1.Year, v2.Year); // Беремо новіший рік

            if (v1 is Car car1)
            {
                if (v2 is Car car2)
                {
                    return new Car(newBrand, combinedModel, newYear, car1.EngineType, (car1.FuelConsumption + car2.FuelConsumption) / 2);
                }
                // Якщо v2 мотоцикл, ми не можемо напряму створити Car з його властивостей, повернемо Car з властивостями v1, але з комбінованою моделлю.
                return new Car(newBrand, combinedModel, newYear, car1.EngineType, car1.FuelConsumption);
            }
            else if (v1 is Motorcycle moto1)
            {
                if (v2 is Motorcycle moto2)
                {
                    return new Motorcycle(newBrand, combinedModel, newYear, moto1.HasSidecar || moto2.HasSidecar, Math.Max(moto1.MaxSpeed, moto2.MaxSpeed));
                }
                // Якщо v2 автомобіль, аналогічно повернемо Motorcycle з властивостями v1, але з комбінованою моделлю.
                return new Motorcycle(newBrand, combinedModel, newYear, moto1.HasSidecar, moto1.MaxSpeed);
            }
            throw new InvalidOperationException("Неможливо об'єднати транспортні засоби невідомого типу.");
        }

        // Перевантаження оператора == для перевірки, чи той самий рік випуску
        public static bool operator ==(Vehicle v1, Vehicle v2)
        {
            if (ReferenceEquals(v1, v2))
            {
                return true;
            }
            if (ReferenceEquals(v1, null) || ReferenceEquals(v2, null))
            {
                return false;
            }
            return v1.Year == v2.Year;
        }

        // Перевантаження оператора !=
        public static bool operator !=(Vehicle v1, Vehicle v2)
        {
            return !(v1 == v2);
        }

        // Перевантаження оператора > для перевірки, чи новіший рік випуску
        public static bool operator >(Vehicle v1, Vehicle v2)
        {
            if (ReferenceEquals(v1, null) || ReferenceEquals(v2, null))
            {
                return false; // Або кинути виняток, залежить від логіки
            }
            return v1.Year > v2.Year;
        }

        // Перевантаження оператора <
        public static bool operator <(Vehicle v1, Vehicle v2)
        {
            if (ReferenceEquals(v1, null) || ReferenceEquals(v2, null))
            {
                return false; // Або кинути виняток
            }
            return v1.Year < v2.Year;
        }

        // Перевантаження оператора >=
        public static bool operator >=(Vehicle v1, Vehicle v2)
        {
            return v1.Year >= v2.Year;
        }

        // Перевантаження оператора <=
        public static bool operator <=(Vehicle v1, Vehicle v2)
        {
            return v1.Year <= v2.Year;
        }

        // Для коректної роботи операторів порівняння необхідно перевизначити Equals та GetHashCode
        public override bool Equals(object obj)
        {
            return this == (obj as Vehicle);
        }

        public override int GetHashCode()
        {
            return Year.GetHashCode() ^ Brand.GetHashCode() ^ Model.GetHashCode();
        }
    }
}
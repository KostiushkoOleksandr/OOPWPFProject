using System;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq; // Додайте цей using для LINQ
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace OOPWPFProject
{

    public class MaintenanceDateConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is DateTime date)
            {

                if (date == DateTime.MinValue)
                {
                    return "Не встановлено";
                }

                return date.ToShortDateString();
            }
            return DependencyProperty.UnsetValue;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }


    public partial class MainWindow : Window
    {

        public ObservableCollection<Vehicle> Vehicles { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            Vehicles = new ObservableCollection<Vehicle>();
            VehiclesDataGrid.ItemsSource = Vehicles;

            VehicleType_Changed(null, null);
        }

        private void VehicleType_Changed(object sender, RoutedEventArgs e)
        {

            if (CarRadioButton == null || MotorcycleFieldsPanel == null) return;


            bool isCar = CarRadioButton.IsChecked == true;

            CarFieldsPanel.Visibility = isCar ? Visibility.Visible : Visibility.Collapsed;
            MotorcycleFieldsPanel.Visibility = isCar ? Visibility.Collapsed : Visibility.Visible;
        }

        private void AddRecord_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                if (string.IsNullOrWhiteSpace(BrandTextBox.Text) ||
                    string.IsNullOrWhiteSpace(ModelTextBox.Text) ||
                    !int.TryParse(YearTextBox.Text, out int year))
                {
                    MessageBox.Show("Будь ласка, заповніть коректно поля: Марка, Модель, Рік.", "Помилка валідації", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                Vehicle newVehicle;


                DateTime lastMaintenanceDate = LastMaintenanceDatePicker.SelectedDate ?? DateTime.MinValue;
                decimal maintenanceCost = 0;
                if (!string.IsNullOrWhiteSpace(MaintenanceCostTextBox.Text))
                {

                    if (!decimal.TryParse(MaintenanceCostTextBox.Text, out maintenanceCost))
                    {
                        MessageBox.Show("Будь ласка, введіть коректну вартість обслуговування.", "Помилка валідації", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }
                }

                if (CarRadioButton.IsChecked == true)
                {

                    if (EngineTypeComboBox.SelectedItem == null || !double.TryParse(FuelConsumptionTextBox.Text, out double fuel))
                    {
                        MessageBox.Show("Будь ласка, заповніть коректно поля для автомобіля (Тип двигуна, Витрата палива).", "Помилка валідації", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }
                    string engineType = (EngineTypeComboBox.SelectedItem as ComboBoxItem).Content.ToString();
                    Car newCar = new Car(BrandTextBox.Text, ModelTextBox.Text, year, engineType, fuel);


                    newCar.LastMaintenanceDate = lastMaintenanceDate;
                    newCar.MaintenanceCost = maintenanceCost;
                    newVehicle = newCar;
                }
                else
                {

                    if (!int.TryParse(MaxSpeedTextBox.Text, out int maxSpeed))
                    {
                        MessageBox.Show("Будь ласка, введіть коректну максимальну швидкість.", "Помилка валідації", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }
                    bool hasSidecar = HasSidecarCheckBox.IsChecked == true;
                    Motorcycle newMotorcycle = new Motorcycle(BrandTextBox.Text, ModelTextBox.Text, year, hasSidecar, maxSpeed);


                    newMotorcycle.LastMaintenanceDate = lastMaintenanceDate;
                    newMotorcycle.MaintenanceCost = maintenanceCost;
                    newVehicle = newMotorcycle;
                }

                Vehicles.Add(newVehicle);
                ClearForm();
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show(ex.Message, "Помилка валідації", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void DeleteRecord_Click(object sender, RoutedEventArgs e)
        {

            if (VehiclesDataGrid.SelectedItem is Vehicle selectedVehicle)
            {
                Vehicles.Remove(selectedVehicle);
            }
            else
            {
                MessageBox.Show("Будь ласка, виберіть запис для видалення.", "Інформація", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void ShowDetails_Click(object sender, RoutedEventArgs e)
        {
            if (VehiclesDataGrid.SelectedItem is Vehicle selectedVehicle)
            {
                MessageBox.Show(selectedVehicle.GetDetails(), "Повна інформація", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("Будь ласка, виберіть запис для перегляду деталей.", "Інформація", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }


        private void ScheduleMaintenance_Click(object sender, RoutedEventArgs e)
        {

            if (VehiclesDataGrid.SelectedItem is IMaintainable maintainableVehicle)
            {
                maintainableVehicle.ScheduleMaintenance();
            }
            else
            {
                MessageBox.Show("Вибраний транспортний засіб не підтримує функцію обслуговування.", "Інформація", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }


        private void CheckServiceNeeds_Click(object sender, RoutedEventArgs e)
        {

            if (VehiclesDataGrid.SelectedItem is IMaintainable maintainableVehicle)
            {
                if (maintainableVehicle.NeedsService())
                {
                    MessageBox.Show($"Транспортний засіб {((Vehicle)maintainableVehicle).Brand} {((Vehicle)maintainableVehicle).Model} потребує обслуговування!", "Потреба в обслуговуванні", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                else
                {
                    MessageBox.Show($"Транспортний засіб {((Vehicle)maintainableVehicle).Brand} {((Vehicle)maintainableVehicle).Model} не потребує обслуговування наразі.", "Потреба в обслуговуванні", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            else
            {
                MessageBox.Show("Вибраний транспортний засіб не підтримує функцію перевірки обслуговування.", "Інформація", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        // --- Нові методи для перевантажених операторів ---

        private void CombineVehicles_Click(object sender, RoutedEventArgs e)
        {
            var selectedVehicles = VehiclesDataGrid.SelectedItems.Cast<Vehicle>().ToList();

            if (selectedVehicles.Count == 2)
            {
                try
                {
                    // Об'єднуємо два вибрані транспортні засоби
                    Vehicle combinedVehicle = selectedVehicles[0] + selectedVehicles[1];
                    Vehicles.Add(combinedVehicle);
                    MessageBox.Show($"Створено новий транспортний засіб шляхом об'єднання: {combinedVehicle.Brand} {combinedVehicle.Model} ({combinedVehicle.Year})", "Об'єднання транспортних засобів", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (ArgumentNullException ex)
                {
                    MessageBox.Show(ex.Message, "Помилка об'єднання", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                catch (InvalidOperationException ex)
                {
                    MessageBox.Show(ex.Message, "Помилка об'єднання", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Будь ласка, виберіть рівно два транспортні засоби для об'єднання.", "Інформація", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void CompareYearsEquals_Click(object sender, RoutedEventArgs e)
        {
            var selectedVehicles = VehiclesDataGrid.SelectedItems.Cast<Vehicle>().ToList();

            if (selectedVehicles.Count == 2)
            {
                Vehicle v1 = selectedVehicles[0];
                Vehicle v2 = selectedVehicles[1];

                if (v1 == v2) // Використовуємо перевантажений оператор ==
                {
                    MessageBox.Show($"Транспортні засоби '{v1.Brand} {v1.Model}' та '{v2.Brand} {v2.Model}' випущено в одному році ({v1.Year}).", "Порівняння років випуску", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show($"Транспортні засоби '{v1.Brand} {v1.Model}' та '{v2.Brand} {v2.Model}' випущено в різних роках.", "Порівняння років випуску", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            else
            {
                MessageBox.Show("Будь ласка, виберіть рівно два транспортні засоби для порівняння.", "Інформація", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void CompareYearsGreater_Click(object sender, RoutedEventArgs e)
        {
            var selectedVehicles = VehiclesDataGrid.SelectedItems.Cast<Vehicle>().ToList();

            if (selectedVehicles.Count == 2)
            {
                Vehicle v1 = selectedVehicles[0];
                Vehicle v2 = selectedVehicles[1];

                if (v1 > v2) // Використовуємо перевантажений оператор >
                {
                    MessageBox.Show($"Транспортний засіб '{v1.Brand} {v1.Model}' ({v1.Year} рік) новіший за '{v2.Brand} {v2.Model}' ({v2.Year} рік).", "Порівняння років випуску", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else if (v2 > v1) // Використовуємо перевантажений оператор >
                {
                    MessageBox.Show($"Транспортний засіб '{v2.Brand} {v2.Model}' ({v2.Year} рік) новіший за '{v1.Brand} {v1.Model}' ({v1.Year} рік).", "Порівняння років випуску", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show($"Транспортні засоби '{v1.Brand} {v1.Model}' та '{v2.Brand} {v2.Model}' випущено в одному році.", "Порівняння років випуску", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            else
            {
                MessageBox.Show("Будь ласка, виберіть рівно два транспортні засоби для порівняння.", "Інформація", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void ClearForm()
        {
            BrandTextBox.Clear();
            ModelTextBox.Clear();
            YearTextBox.Clear();
            EngineTypeComboBox.SelectedIndex = -1;
            FuelConsumptionTextBox.Clear();
            MaxSpeedTextBox.Clear();
            HasSidecarCheckBox.IsChecked = false;
            LastMaintenanceDatePicker.SelectedDate = null;
            MaintenanceCostTextBox.Clear();
        }
    }
}
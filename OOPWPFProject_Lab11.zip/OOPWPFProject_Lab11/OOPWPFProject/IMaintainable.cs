﻿using System;

namespace OOPWPFProject
{
    public interface IMaintainable
    {
        DateTime LastMaintenanceDate { get; set; }
        decimal MaintenanceCost { get; set; }

        void ScheduleMaintenance();
        bool NeedsService();
    }
}
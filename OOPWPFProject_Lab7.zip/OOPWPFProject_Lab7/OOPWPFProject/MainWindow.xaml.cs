using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace OOPWPFProject
{
    public partial class MainWindow : Window
    {
        public ObservableCollection<Car> Cars { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            Cars = new ObservableCollection<Car>();
            CarsDataGrid.ItemsSource = Cars;
        }

        private void AddRecord_Click(object sender, RoutedEventArgs e)
        {
            if (BrandComboBox.SelectedItem == null || ModelComboBox.SelectedItem == null || string.IsNullOrWhiteSpace(YearTextBox.Text))
            {
                MessageBox.Show("Марка, модель та рік є обов'язковими полями.", "Помилка валідації", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            AddCarToList(
                (BrandComboBox.SelectedItem as ComboBoxItem).Content.ToString(),
                (ModelComboBox.SelectedItem as ComboBoxItem).Content.ToString(),
                YearTextBox.Text,
                (EngineTypeComboBox.SelectedItem as ComboBoxItem)?.Content.ToString(),
                MileageTextBox.Text
            );
        }

        private void AddCarToList(string brand, string model, string yearStr, string engineType, string mileageStr)
        {
            try
            {
                if (!int.TryParse(yearStr, out int year))
                {
                    MessageBox.Show($"Будь ласка, введіть коректний рік випуску.", "Помилка валідації", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                var car = new Car(brand, model, year);

                car.EngineType = string.IsNullOrWhiteSpace(engineType) ? "Не вказано" : engineType;

                if (!string.IsNullOrWhiteSpace(mileageStr) && int.TryParse(mileageStr, out int mileage) && mileage >= 0)
                {
                    car.Mileage = mileage;
                }

                Cars.Add(car);
                ClearForm();
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show(ex.Message, "Помилка валідації", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void DeleteRecord_Click(object sender, RoutedEventArgs e)
        {
            if (CarsDataGrid.SelectedItem is Car selectedCar)
            {
                Cars.Remove(selectedCar);
            }
            else
            {
                MessageBox.Show("Будь ласка, виберіть запис для видалення.", "Інформація", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
        private void SortButton_Click(object sender, RoutedEventArgs e)
        {
            if (SortFieldComboBox.SelectedItem == null)
            {
                MessageBox.Show("Будь ласка, оберіть поле для сортування.", "Інформація", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            string field = (SortFieldComboBox.SelectedItem as ComboBoxItem).Content.ToString();
            bool isDescending = SortDescendingCheckBox.IsChecked == true;

            List<Car> sortedCars;

            switch (field)
            {
                case "Маркою":
                    sortedCars = isDescending ? Cars.OrderByDescending(c => c.Brand).ToList() : Cars.OrderBy(c => c.Brand).ToList();
                    break;
                case "Моделлю":
                    sortedCars = isDescending ? Cars.OrderByDescending(c => c.Model).ToList() : Cars.OrderBy(c => c.Model).ToList();
                    break;
                case "Роком":
                    sortedCars = isDescending ? Cars.OrderByDescending(c => c.Year).ToList() : Cars.OrderBy(c => c.Year).ToList();
                    break;
                case "Пробігом":
                    sortedCars = isDescending ? Cars.OrderByDescending(c => c.Mileage).ToList() : Cars.OrderBy(c => c.Mileage).ToList();
                    break;
                default:
                    return;
            }

            Cars.Clear();
            foreach (var car in sortedCars)
            {
                Cars.Add(car);
            }
        }

        private void ClearForm_Click(object sender, RoutedEventArgs e) => ClearForm();

        private void ClearForm()
        {
            BrandComboBox.SelectedIndex = -1;
            ModelComboBox.SelectedIndex = -1;
            YearTextBox.Clear();
            EngineTypeComboBox.SelectedIndex = -1;
            MileageTextBox.Clear();
        }
    }
}
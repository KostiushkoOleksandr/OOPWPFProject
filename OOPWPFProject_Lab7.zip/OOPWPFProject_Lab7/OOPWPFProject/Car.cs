﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPWPFProject
{
    public class Car : ICloneable
    {
        public string Brand { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
        public string EngineType { get; set; }
        public int? Mileage { get; set; }

        public Car() { }

        public Car(string brand, string model, int year)
        {
            if (string.IsNullOrWhiteSpace(brand))
                throw new ArgumentException("Марка не може бути порожньою.", nameof(brand));

            if (string.IsNullOrWhiteSpace(model))
                throw new ArgumentException("Модель не може бути порожньою.", nameof(model));

            if (year < 1900 || year > DateTime.Now.Year)
                throw new ArgumentException($"Рік повинен бути в межах від 1900 до {DateTime.Now.Year}.", nameof(year));

            Brand = brand;
            Model = model;
            Year = year;
            EngineType = "Не вказано";
        }

        public override string ToString()
        {
            string mileageInfo = Mileage.HasValue ? $"{Mileage} км" : "не вказано";
            return $"Автомобіль: {Brand} {Model}, {Year} року. Двигун: {EngineType}, Пробіг: {mileageInfo}";
        }

        public object Clone()
        {
            return this.MemberwiseClone();
        }
    }
}
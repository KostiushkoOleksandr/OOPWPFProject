﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace OOPWPFProject
{
    public class TypeNameConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value == null) return string.Empty;
            string typeName = value.GetType().Name;
            return typeName == "Car" ? "Автомобіль" : typeName == "Motorcycle" ? "Мотоцикл" : typeName;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
﻿using System;
using System.Collections.ObjectModel;
using System.Text;

namespace OOPWPFProject
{
    public class EntityManager
    {
  
        public ObservableCollection<Vehicle> Items { get; private set; }

        public EntityManager()
        {
            Items = new ObservableCollection<Vehicle>();
        }

      
        public Vehicle this[int index]
        {
            get
            {
                if (index < 0 || index >= Items.Count)
                {
                    throw new IndexOutOfRangeException("Індекс знаходиться поза межами колекції.");
                }
                return Items[index];
            }
            set
            {
                if (index < 0 || index >= Items.Count)
                {
                    throw new IndexOutOfRangeException("Індекс знаходиться поза межами колекції.");
                }
                Items[index] = value;
            }
        }

       
        public void Add(Vehicle item)
        {
            Items.Add(item);
        }

        public void Remove(Vehicle item)
        {
            Items.Remove(item);
        }

        public string DisplayAll()
        {
            if (Items.Count == 0)
            {
                return "Список порожній.";
            }

            StringBuilder sb = new StringBuilder();
            foreach (var vehicle in Items) 
            {
                sb.AppendLine(vehicle.ToString());
            }
            return sb.ToString();
        }
    }
}
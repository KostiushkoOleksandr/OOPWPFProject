﻿using System;

namespace OOPWPFProject
{
    
    public abstract class Vehicle : AbstractVehicle
    {
        protected Vehicle(string brand, string model, int year)
            : base(brand, model, year) 
        {
        }

        public override string GetDetails()
        {
            return $"Тип: {this.GetType().Name}\nМарка: {Brand}\nМодель: {Model}\nРік: {Year}";
        }

        public override string ToString()
        {
            return $"{Brand} {Model} ({Year})";
        }
    }
}
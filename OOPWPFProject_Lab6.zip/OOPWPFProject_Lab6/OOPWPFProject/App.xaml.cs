using System.Windows;

namespace OOPWPFProject
{
    public partial class App : Application
    {
    }
}

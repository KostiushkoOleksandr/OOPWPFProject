using System;
using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;

namespace OOPWPFProject
{
    public partial class MainWindow : Window
    {
        public ObservableCollection<Car> Cars { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            Cars = new ObservableCollection<Car>();
            CarsDataGrid.ItemsSource = Cars;
        }

        private void AddRecord_Click(object sender, RoutedEventArgs e)
        {
            if (BrandComboBox.SelectedItem == null)
            {
                MessageBox.Show("Будь ласка, виберіть марку автомобіля.", "Помилка валідації", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (ModelComboBox.SelectedItem == null)
            {
                MessageBox.Show("Будь ласка, виберіть модель автомобіля.", "Помилка валідації", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (string.IsNullOrWhiteSpace(YearTextBox.Text) || !int.TryParse(YearTextBox.Text, out int year) || year < 1900 || year > DateTime.Now.Year)
            {
                MessageBox.Show($"Будь ласка, введіть коректний рік випуску (наприклад, {DateTime.Now.Year}).", "Помилка валідації", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            int? mileage = null;
            if (!string.IsNullOrWhiteSpace(MileageTextBox.Text))
            {
                if (int.TryParse(MileageTextBox.Text, out int parsedMileage) && parsedMileage >= 0)
                {
                    mileage = parsedMileage;
                }
                else
                {
                    MessageBox.Show("Будь ласка, введіть коректне значення пробігу (невід'ємне число).", "Помилка валідації", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
            }

            var car = new Car
            {
                Brand = (BrandComboBox.SelectedItem as ComboBoxItem).Content.ToString(),
                Model = (ModelComboBox.SelectedItem as ComboBoxItem).Content.ToString(),
                Year = year,
                EngineType = (EngineTypeComboBox.SelectedItem as ComboBoxItem)?.Content.ToString() ?? "Не вказано",
                Mileage = mileage
            };

            Cars.Add(car);
            ClearForm();
        }

        private void DeleteRecord_Click(object sender, RoutedEventArgs e)
        {
            if (CarsDataGrid.SelectedItem is Car selectedCar)
            {
                Cars.Remove(selectedCar);
            }
            else
            {
                MessageBox.Show("Будь ласка, виберіть запис для видалення.", "Інформація", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void ClearForm_Click(object sender, RoutedEventArgs e)
        {
            ClearForm();
        }

        private void ClearForm()
        {
            BrandComboBox.SelectedIndex = -1;
            ModelComboBox.SelectedIndex = -1;
            YearTextBox.Clear();
            EngineTypeComboBox.SelectedIndex = -1;
            MileageTextBox.Clear();
        }
    }
}
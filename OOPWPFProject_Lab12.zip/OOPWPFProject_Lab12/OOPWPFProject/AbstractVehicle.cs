﻿using System;

namespace OOPWPFProject
{
    public abstract class AbstractVehicle
    {
        public string Brand { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
    
        public AbstractVehicle() { }

        protected AbstractVehicle(string brand, string model, int year)
        {
            if (string.IsNullOrWhiteSpace(brand))
                throw new ArgumentException("Бренд не може бути порожнім.", nameof(brand));
            if (string.IsNullOrWhiteSpace(model))
                throw new ArgumentException("Модель не може бути порожньою.", nameof(model));
            if (year < 1900 || year > DateTime.Now.Year + 1)
                throw new ArgumentException($"Рік має бути між 1900 та {DateTime.Now.Year + 1}.", nameof(year));

            Brand = brand;
            Model = model;
            Year = year;
        }

        public abstract string GetDetails();
    }
}
﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;

namespace OOPWPFProject
{
    public sealed class Car : Vehicle, IMaintainable
    {
        private string _engineType;
        public string EngineType
        {
            get { return _engineType; }
            set
            {
                if (_engineType != value)
                {
                    _engineType = value;
                    OnPropertyChanged();
                }
            }
        }

        private double _fuelConsumption;
        public double FuelConsumption
        {
            get { return _fuelConsumption; }
            set
            {
                if (_fuelConsumption != value)
                {
                    _fuelConsumption = value;
                    OnPropertyChanged();
                }
            }
        }

        private DateTime _lastMaintenanceDate;
        public DateTime LastMaintenanceDate
        {
            get { return _lastMaintenanceDate; }
            set
            {
                if (_lastMaintenanceDate != value)
                {
                    _lastMaintenanceDate = value;
                    OnPropertyChanged();
                }
            }
        }

        private decimal _maintenanceCost;
        public decimal MaintenanceCost
        {
            get { return _maintenanceCost; }
            set
            {
                if (_maintenanceCost != value)
                {
                    _maintenanceCost = value;
                    OnPropertyChanged();
                }
            }
        }

        public Car() : base() { }

        public Car(string brand, string model, int year, string engineType, double fuelConsumption)
            : base(brand, model, year)
        {
            EngineType = engineType;
            FuelConsumption = fuelConsumption;
            LastMaintenanceDate = DateTime.MinValue;
            MaintenanceCost = 0;
        }

        public override string GetDetails()
        {
            string baseDetails = base.GetDetails();
            return $"{baseDetails}\nТип двигуна: {EngineType}\nВитрата палива (л/100км): {FuelConsumption}\n" +
                   $"Останнє обслуговування: {(LastMaintenanceDate == DateTime.MinValue ? "Не встановлено" : LastMaintenanceDate.ToShortDateString())}\nВартість обслуговування: {MaintenanceCost:C}";
        }

        public void ScheduleMaintenance()
        {
            MessageBox.Show($"Планується обслуговування для автомобіля {Brand} {Model}. Зверніться до сервісного центру.", "Планування обслуговування", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        public bool NeedsService()
        {
            return (DateTime.Now - LastMaintenanceDate).TotalDays > 365 && LastMaintenanceDate != DateTime.MinValue;
        }
    }
}
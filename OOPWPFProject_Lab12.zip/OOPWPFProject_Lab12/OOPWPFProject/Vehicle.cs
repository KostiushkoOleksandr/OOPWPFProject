﻿using System;
using System.ComponentModel; // Додано для INotifyPropertyChanged
using System.Runtime.CompilerServices; // Додано для CallerMemberName
using System.Xml.Serialization;

namespace OOPWPFProject
{
    [XmlInclude(typeof(Car))]
    [XmlInclude(typeof(Motorcycle))]
    public abstract class Vehicle : AbstractVehicle, INotifyPropertyChanged
    {
        private bool _isSelected;
        public bool IsSelected
        {
            get { return _isSelected; }
            set
            {
                if (_isSelected != value)
                {
                    _isSelected = value;
                    OnPropertyChanged();
                }
            }
        }

        public Vehicle() : base() { }

        protected Vehicle(string brand, string model, int year)
            : base(brand, model, year)
        {
        }

        public override string GetDetails()
        {
            return $"Тип: {this.GetType().Name}\nМарка: {Brand}\nМодель: {Model}\nРік: {Year}";
        }

        public override string ToString()
        {
            return $"{Brand} {Model} ({Year})";
        }

        // Оператори
        public static Vehicle operator +(Vehicle v1, Vehicle v2)
        {
            if (v1 == null || v2 == null)
            {
                throw new ArgumentNullException("Обидва об'єкти транспортних засобів повинні бути ініціалізовані для операції '+'.");
            }
            string combinedModel = $"{v1.Model}-{v2.Model}";
            string newBrand = v1.Brand;
            int newYear = Math.Max(v1.Year, v2.Year);

            if (v1 is Car car1)
            {
                if (v2 is Car car2)
                {
                    return new Car(newBrand, combinedModel, newYear, car1.EngineType, (car1.FuelConsumption + car2.FuelConsumption) / 2);
                }

                return new Car(newBrand, combinedModel, newYear, car1.EngineType, car1.FuelConsumption);
            }
            else if (v1 is Motorcycle moto1)
            {
                if (v2 is Motorcycle moto2)
                {
                    return new Motorcycle(newBrand, combinedModel, newYear, moto1.HasSidecar || moto2.HasSidecar, Math.Max(moto1.MaxSpeed, moto2.MaxSpeed));
                }

                return new Motorcycle(newBrand, combinedModel, newYear, moto1.HasSidecar, moto1.MaxSpeed);
            }
            throw new InvalidOperationException("Неможливо об'єднати транспортні засоби невідомого типу.");
        }


        public static bool operator ==(Vehicle v1, Vehicle v2)
        {
            if (ReferenceEquals(v1, v2))
            {
                return true;
            }
            if (ReferenceEquals(v1, null) || ReferenceEquals(v2, null))
            {
                return false;
            }
            return v1.Year == v2.Year;
        }

        public static bool operator !=(Vehicle v1, Vehicle v2)
        {
            return !(v1 == v2);
        }

        public static bool operator >(Vehicle v1, Vehicle v2)
        {
            if (ReferenceEquals(v1, null) || ReferenceEquals(v2, null))
            {
                return false;
            }
            return v1.Year > v2.Year;
        }

        public static bool operator <(Vehicle v1, Vehicle v2)
        {
            if (ReferenceEquals(v1, null) || ReferenceEquals(v2, null))
            {
                return false;
            }
            return v1.Year < v2.Year;
        }

        public static bool operator >=(Vehicle v1, Vehicle v2)
        {
            return v1.Year >= v2.Year;
        }

        public static bool operator <=(Vehicle v1, Vehicle v2)
        {
            return v1.Year <= v2.Year;
        }

        public override bool Equals(object obj)
        {
            return this == (obj as Vehicle);
        }

        public override int GetHashCode()
        {
            return Year.GetHashCode() ^ Brand.GetHashCode() ^ Model.GetHashCode();
        }

        // Реалізація INotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}
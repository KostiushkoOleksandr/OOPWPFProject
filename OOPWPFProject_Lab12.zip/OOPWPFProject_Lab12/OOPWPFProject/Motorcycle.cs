﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;

namespace OOPWPFProject
{
    public sealed class Motorcycle : Vehicle, IMaintainable
    {
        private bool _hasSidecar;
        public bool HasSidecar
        {
            get { return _hasSidecar; }
            set
            {
                if (_hasSidecar != value)
                {
                    _hasSidecar = value;
                    OnPropertyChanged();
                }
            }
        }

        private int _maxSpeed;
        public int MaxSpeed
        {
            get { return _maxSpeed; }
            set
            {
                if (_maxSpeed != value)
                {
                    _maxSpeed = value;
                    OnPropertyChanged();
                }
            }
        }

        private DateTime _lastMaintenanceDate;
        public DateTime LastMaintenanceDate
        {
            get { return _lastMaintenanceDate; }
            set
            {
                if (_lastMaintenanceDate != value)
                {
                    _lastMaintenanceDate = value;
                    OnPropertyChanged();
                }
            }
        }

        private decimal _maintenanceCost;
        public decimal MaintenanceCost
        {
            get { return _maintenanceCost; }
            set
            {
                if (_maintenanceCost != value)
                {
                    _maintenanceCost = value;
                    OnPropertyChanged();
                }
            }
        }

        public Motorcycle() : base() { }

        public Motorcycle(string brand, string model, int year, bool hasSidecar, int maxSpeed)
            : base(brand, model, year)
        {
            HasSidecar = hasSidecar;
            MaxSpeed = maxSpeed;
            LastMaintenanceDate = DateTime.MinValue;
            MaintenanceCost = 0;
        }

        public override string GetDetails()
        {
            string baseDetails = base.GetDetails();
            return $"{baseDetails}\nНаявність коляски: {(HasSidecar ? "Так" : "Ні")}\nМакс. швидкість (км/год): {MaxSpeed}\n" +
                   $"Останнє обслуговування: {(LastMaintenanceDate == DateTime.MinValue ? "Не встановлено" : LastMaintenanceDate.ToShortDateString())}\nВартість обслуговування: {MaintenanceCost:C}";
        }


        public void ScheduleMaintenance()
        {
            MessageBox.Show($"Планується обслуговування для мотоцикла {Brand} {Model}. Перевірте рівень мастила та гальма.", "Планування обслуговування", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        public bool NeedsService()
        {
            return (DateTime.Now - LastMaintenanceDate).TotalDays > 180 && LastMaintenanceDate != DateTime.MinValue;
        }
    }
}
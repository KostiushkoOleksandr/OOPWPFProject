﻿namespace OOPWPFProject
{
    public sealed class Motorcycle : Vehicle
    {
        public bool HasSidecar { get; set; }
        public int MaxSpeed { get; set; }

        public Motorcycle(string brand, string model, int year, bool hasSidecar, int maxSpeed)
            : base(brand, model, year)
        {
            HasSidecar = hasSidecar;
            MaxSpeed = maxSpeed;
        }

        public override string GetDetails()
        {
            string baseDetails = base.GetDetails();
            return $"{baseDetails}\nНаявність коляски: {(HasSidecar ? "Так" : "Ні")}\nМакс. швидкість (км/год): {MaxSpeed}";
        }
    }
}
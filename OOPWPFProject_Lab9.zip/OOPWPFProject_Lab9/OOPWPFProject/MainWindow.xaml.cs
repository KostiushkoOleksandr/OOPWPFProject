using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;

namespace OOPWPFProject
{
    public partial class MainWindow : Window
    {
        // Завдання 7: Оновлюємо колекцію для зберігання об'єктів базового класу Vehicle
        public ObservableCollection<Vehicle> Vehicles { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            Vehicles = new ObservableCollection<Vehicle>();
            VehiclesDataGrid.ItemsSource = Vehicles;
        }

        private void VehicleType_Changed(object sender, RoutedEventArgs e)
        {
            if (CarRadioButton == null || MotorcycleFieldsPanel == null) return;

            bool isCar = CarRadioButton.IsChecked == true;
            CarFieldsPanel.Visibility = isCar ? Visibility.Visible : Visibility.Collapsed;
            MotorcycleFieldsPanel.Visibility = isCar ? Visibility.Collapsed : Visibility.Visible;
        }

        private void AddRecord_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Basic validation
                if (string.IsNullOrWhiteSpace(BrandTextBox.Text) ||
                    string.IsNullOrWhiteSpace(ModelTextBox.Text) ||
                    !int.TryParse(YearTextBox.Text, out int year))
                {
                    MessageBox.Show("Будь ласка, заповніть коректно поля: Марка, Модель, Рік.", "Помилка валідації", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                Vehicle newVehicle;

                if (CarRadioButton.IsChecked == true)
                {
                    // Create a Car
                    if (EngineTypeComboBox.SelectedItem == null || !double.TryParse(FuelConsumptionTextBox.Text, out double fuel))
                    {
                        MessageBox.Show("Будь ласка, заповніть коректно поля для автомобіля.", "Помилка валідації", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }
                    string engineType = (EngineTypeComboBox.SelectedItem as ComboBoxItem).Content.ToString();
                    newVehicle = new Car(BrandTextBox.Text, ModelTextBox.Text, year, engineType, fuel);
                }
                else
                {
                    // Create a Motorcycle
                    if (!int.TryParse(MaxSpeedTextBox.Text, out int maxSpeed))
                    {
                        MessageBox.Show("Будь ласка, введіть коректну максимальну швидкість.", "Помилка валідації", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }
                    bool hasSidecar = HasSidecarCheckBox.IsChecked == true;
                    newVehicle = new Motorcycle(BrandTextBox.Text, ModelTextBox.Text, year, hasSidecar, maxSpeed);
                }

                Vehicles.Add(newVehicle);
                ClearForm();
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show(ex.Message, "Помилка валідації", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void DeleteRecord_Click(object sender, RoutedEventArgs e)
        {
            if (VehiclesDataGrid.SelectedItem is Vehicle selectedVehicle)
            {
                Vehicles.Remove(selectedVehicle);
            }
            else
            {
                MessageBox.Show("Будь ласка, виберіть запис для видалення.", "Інформація", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void ShowDetails_Click(object sender, RoutedEventArgs e)
        {
            if (VehiclesDataGrid.SelectedItem is Vehicle selectedVehicle)
            {
                // Polymorphic call to GetDetails()
                MessageBox.Show(selectedVehicle.GetDetails(), "Повна інформація", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("Будь ласка, виберіть запис для перегляду деталей.", "Інформація", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void ClearForm()
        {
            BrandTextBox.Clear();
            ModelTextBox.Clear();
            YearTextBox.Clear();
            EngineTypeComboBox.SelectedIndex = -1;
            FuelConsumptionTextBox.Clear();
            MaxSpeedTextBox.Clear();
            HasSidecarCheckBox.IsChecked = false;
        }
    }
}
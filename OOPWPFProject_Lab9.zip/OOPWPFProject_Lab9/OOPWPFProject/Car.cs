﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPWPFProject
{
    public sealed class Car : Vehicle
    {
        public string EngineType { get; set; }
        public double FuelConsumption { get; set; }

        public Car(string brand, string model, int year, string engineType, double fuelConsumption)
            : base(brand, model, year)
        {
            EngineType = engineType;
            FuelConsumption = fuelConsumption;
        }

        public override string GetDetails()
        {
            string baseDetails = base.GetDetails();
            return $"{baseDetails}\nТип двигуна: {EngineType}\nВитрата палива (л/100км): {FuelConsumption}";
        }
    }
}
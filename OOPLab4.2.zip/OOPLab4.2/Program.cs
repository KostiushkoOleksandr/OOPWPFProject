using System;
using System.Collections.Generic;
using System.Linq;

struct Car
{
    public string Brand;
    public string Model;
    public int Year;
    public string EngineType;
    public int Mileage;

    public Car(string brand, string model, int year, string engineType, int mileage)
    {
        Brand = brand;
        Model = model;
        Year = year;
        EngineType = engineType;
        Mileage = mileage;
    }

    public void Display()
    {
        Console.WriteLine($"{Brand,-10} | {Model,-10} | {Year,-6} | {EngineType,-10} | {Mileage,7} km");
    }
}

class Program
{
    static List<Car> cars = new();

    static void Main()
    {
        while (true)
        {
            Console.Clear();
            Console.WriteLine("1. Вивести записи");
            Console.WriteLine("2. Додати запис");
            Console.WriteLine("3. Видалити запис (за iндексом)");
            Console.WriteLine("4. Сортування");
            Console.WriteLine("5. Пошук");
            Console.WriteLine("6. Вихiд");
            Console.Write("Ваш вибiр: ");
            var choice = Console.ReadLine();

            switch (choice)
            {
                case "1": ShowAll(); break;
                case "2": AddCar(); break;
                case "3": DeleteCar(); break;
                case "4": SortMenu(); break;
                case "5": SearchMenu(); break;
                case "6": return;
                default: Console.WriteLine("Невiрний вибiр!"); break;
            }

            Console.WriteLine("Натиснiть будь-яку клавiшу...");
            Console.ReadKey();
        }
    }

    static void ShowAll()
    {
        Console.WriteLine("\nМарка      | Модель     | Рiк    | Двигун     | Пробiг");
        Console.WriteLine(new string('-', 55));
        foreach (var car in cars)
            car.Display();
    }

    static void AddCar()
    {
        Console.Write("Марка: "); string brand = Console.ReadLine();
        Console.Write("Модель: "); string model = Console.ReadLine();
        Console.Write("Рiк: "); int year = int.Parse(Console.ReadLine());
        Console.Write("Тип двигуна: "); string engine = Console.ReadLine();
        Console.Write("Пробiг (км): "); int mileage = int.Parse(Console.ReadLine());

        cars.Add(new Car(brand, model, year, engine, mileage));
    }

    static void DeleteCar()
    {
        ShowAll();
        Console.Write("Введiть iндекс для видалення (починаючи з 0): ");
        int index = int.Parse(Console.ReadLine());
        if (index >= 0 && index < cars.Count)
            cars.RemoveAt(index);
        else
            Console.WriteLine("Невiрний iндекс.");
    }

    static void SortMenu()
    {
        Console.WriteLine("Сортувати за:");
        Console.WriteLine("1. Марка");
        Console.WriteLine("2. Рiк");
        var choice = Console.ReadLine();

        if (choice == "1")
            cars = cars.OrderBy(c => c.Brand).ToList();
        else if (choice == "2")
            cars = cars.OrderBy(c => c.Year).ToList();
        else
            Console.WriteLine("Невiрний вибiр.");
    }

    static void SearchMenu()
    {
        Console.WriteLine("Пошук за:");
        Console.WriteLine("1. Марка");
        Console.WriteLine("2. Рiк");
        var choice = Console.ReadLine();

        if (choice == "1")
        {
            Console.Write("Введiть марку: ");
            string brand = Console.ReadLine();
            var result = cars.Where(c => c.Brand.ToLower().Contains(brand.ToLower()));
            foreach (var car in result) car.Display();
        }
        else if (choice == "2")
        {
            Console.Write("Введiть рiк: ");
            int year = int.Parse(Console.ReadLine());
            var result = cars.Where(c => c.Year == year);
            foreach (var car in result) car.Display();
        }
        else Console.WriteLine("Невiрний вибiр.");
    }
}